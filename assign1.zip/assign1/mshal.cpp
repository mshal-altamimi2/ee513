#include<iostream>
#include I2CDevice.h


uint8_t uint_to_bcd2(uint8_t ui)
{
uint8_t upper_bcd=(ui/10);
uint8_t lower_bcd=(ui%10);
return upper_bcd |lower_bcd;
}
int main)(int argc,char*argv[]){
EE513::I2CDevice dev(1,0X68);
INT STATUS=DEV.OPEN();
IF(STATUS !=0){std::cout<<"failed open device,with return code"<<status<<std::endl;
}
dev.writeRegister(oxo);
std::cout<<(int)ret<<std::endl;
return 0;

