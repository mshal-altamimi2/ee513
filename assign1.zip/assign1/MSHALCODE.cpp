#include "I2CDevice.h"
#include <iostream>
#include <sstream>
#include <fcntl.h>
#include <stdio.h>
#include <iomanip>
#include <unistd.h>


using namespace std;

#define HEX(x) setw(2) << setfill('0') << hex << (int)(x)

uint8_t uint_to_bcd2(uint8_t ui) {
	uint8_t upper_bcd = (ui/10) << 4;
	uint8_t lower_bcd = (ui%10);
	return upper_bcd | lower_bcd;
}

uint8_t bcd2_to_uint(uint8_t bcd) {
	uint8_t upper_bcd = (bcd >> 4) * 10;
	uint8_t lower_bcd = bcd & 0xF;
	return upper_bcd + lower_bcd;
}

namespace EE513 {


	class DS3231 : public I2CDevice {
		private:
			const unsigned int DS3231_ADDRESS = 0x68;
			const unsigned int DS3231_CONTROL = 0x0E;
			const unsigned int DS3231_STATUSREG = 0x0F;
			const unsigned int DS3231_TEMPERATURE = 0x11;
			const unsigned int DS3231_ALARM1 = 0x07;
			const unsigned int DS3231_ALARM2 = 0x0B;

		public:
			DS3231(unsigned int bus, unsigned int device) : I2CDevice(bus, device) {};

			// Read and display the current RTC module time and date
			void getDatetime() {
				unsigned char* data = this->readRegisters(7, 0x00);
				int second = (data[0] >> 4) * 10 + (data[0] & 0x0F);
				int minute = (data[1] >> 4) * 10 + (data[1] & 0x0F);
				int hour = (data[2] >> 4) * 10 + (data[2] & 0x0F);
				int day = (data[4] >> 4) * 10 + (data[4] & 0x0F);
				int month = (data[5] >> 4) * 10 + (data[5] & 0x0F);
				int year = (data[6] >> 4) * 10 + (data[6] & 0x0F) + 2000;

				cout << "Current time: " << setfill('0') << setw(2) << hour << ":" << setw(2) << minute << ":" <<
					setw(2) << second << endl;
				cout << "Current date: " << setfill('0') << setw(2) << day << "/" << setw(2) << month << "/" <<
					setw(4) << year << endl;
			}

			// Read and display the current temperature
			void getTemperature() {
				unsigned char temp_msb = this->readRegister(DS3231_TEMPERATURE);
				unsigned char temp_lsb = this->readRegister(DS3231_TEMPERATURE + 1);
				int temp_integer = (int)temp_msb;
				float temp_decimal = (float)temp_lsb / 256.0;
				float temperature = temp_integer + temp_decimal;
				cout << "Current temperature: " << temperature << " degrees Celsius" << endl;
			}

			// Set the current time and date on the RTC module
			void setDatetime(int year, int month, int day, int hour,int minute,int second) {
				this->writeRegister(0x00, uint_to_bcd2((uint8_t) second)); //second
				this->writeRegister(0x01, uint_to_bcd2((uint8_t) minute)); //minute
				this->writeRegister(0x02, uint_to_bcd2((uint8_t) hour)); //hour
				this->writeRegister(0x4, uint_to_bcd2((uint8_t) day)); //date
				this->writeRegister(0x5, uint_to_bcd2((uint8_t) month)); //month
				this->writeRegister(0x6, uint_to_bcd2((uint8_t) year-2000)); //year

				cout << "Set time to: " << setfill('0') << setw(2) << hour << ":" << setw(2) << minute << ":" <<
					setw(2) << second << endl;
				cout << "Set date to: " << setfill('0') << setw(2) << day << "/" << setw(2) << month << "/" <<
					setw(4) << year << endl;
			}

			// Set the alarm 2 time on the RTC module
			void setAlarm(int hour, int minute, int second, int date) {
				this->writeRegister(0x7, uint_to_bcd2((uint8_t) second)); //second
				this->writeRegister(0x8, uint_to_bcd2((uint8_t) minute)); //MINUTE
				this->writeRegister(0x9, uint_to_bcd2((uint8_t) hour)); //HOUR
				this->writeRegister(0xA, uint_to_bcd2((uint8_t) date)); //DAY

				//set the A1IE AND INTCN
				cout << "Set alarm to: hour:minute:second day " << setfill('0') << setw(2) << hour << ":" << setw(2) << minute << ":" <<
					setw(2) << second << " " << setw(2) << date << endl;

				char ctl=this->readRegister(0xe);
				ctl=ctl|(1<<0);
				ctl=ctl |(1<<2);
				this->writeRegister(0xe,ctl);
			}

			// Get the status of the alarm interrupt flag
			bool getAlarmStatus() {
				unsigned char status = this->readRegister(DS3231_STATUSREG);
				return (status & 0x01);
			}

			// Clear the alarm interrupt flag
			void clearAlarmFlag() {
				unsigned char status = this->readRegister(DS3231_STATUSREG);
				this->writeRegister(DS3231_STATUSREG, status & 0xFE);
			}
	};
}//namespace EE513

int main(int argc, char *argv[]) {
	EE513::DS3231 rtc(2, 0x68); // Connect to RTC module on I2C bus 1 with address 0x68

	if (argc == 1) {
	rtc.getTemperature(); // Display current temperature
	rtc.setDatetime(2023, 3, 1, 12, 30, 0); // Set date and time to Feb 28, 2023 11:30:00 AM //TODO

	cout << "sleep for 2 sec" << endl;
	usleep(2000000);  //sleep for 2 sec

	rtc.getDatetime(); // Display current date and time

	rtc.setAlarm(12, 31, 0, 1); // Set alarm to trigger at 12:00:00 PM in 24-hour mode

	} else {
	bool alarm_status = rtc.getAlarmStatus(); // Check if the alarm interrupt flag is set
	if (alarm_status) {
		cout << "Alarm triggered!" << endl;
		rtc.clearAlarmFlag(); // Clear the alarm interrupt flag
	} else {
		cout << "Alarm is not triggered!" << endl;
	}
	}
	return 0;
}
