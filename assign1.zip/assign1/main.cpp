#include<iostream>
#include<stdint.h>

#include<time.h>

#include "I2CDevice.h"

// see the webpage in group
// and datasheet   hghghghg
uint8_t uint_to_bcd2(uint8_t ui) {
  uint8_t upper_bcd = (ui/10) << 4;
  uint8_t lower_bcd = (ui%10);
  return upper_bcd | lower_bcd;
}

uint8_t bcd2_to_uint(uint8_t bcd) {
  uint8_t upper_bcd = (bcd >> 4) * 10;
  uint8_t lower_bcd = bcd & 0xF;
  return upper_bcd + lower_bcd;
}

//     argument counts
//     argument values
int main(int argc, char *argv[]){
  EE513::I2CDevice dev(/*bus*/2,/*device*/0x68);

  time_t T = time(NULL);
  struct tm *curr = localtime(&T);

  dev.writeRegister(0x0, uint_to_bcd2((uint8_t) curr->tm_sec)); //sec
  dev.writeRegister(0x1, uint_to_bcd2((uint8_t) curr->tm_min)); //min
  dev.writeRegister(0x2, uint_to_bcd2((uint8_t) curr->tm_hour)); //hour
  dev.writeRegister(0x4, uint_to_bcd2((uint8_t) curr->tm_mday)); //sec
  dev.writeRegister(0x5, uint_to_bcd2((uint8_t) curr->tm_mon + 1)); //min
  dev.writeRegister(0x6, uint_to_bcd2((uint8_t) curr->tm_year - 100)); //hour
  
  uint8_t sec = bcd2_to_uint(dev.readRegister(/*addr*/0x0));
  uint8_t min = bcd2_to_uint(dev.readRegister(/*addr*/0x1));
  uint8_t hou = bcd2_to_uint(dev.readRegister(/*addr*/0x2));
  uint8_t diw = bcd2_to_uint(dev.readRegister(/*addr*/0x3));
  uint8_t dim = bcd2_to_uint(dev.readRegister(/*addr*/0x4));
  uint8_t mon = bcd2_to_uint(dev.readRegister(/*addr*/0x5));
  uint16_t yea = bcd2_to_uint(dev.readRegister(/*addr*/0x6)) + 2000;
  printf("Year:Mon:Day  Hour:Min:Sec:    %d:%d:%d    %d:%d:%d\n", yea, mon, dim, hou, min, sec);

  int8_t temp_msb = dev.readRegister(/*addr*/0x11);
  uint8_t temp_lsb = dev.readRegister(/*addr*/0x12);

  float temp = temp_msb * 1.0f + temp_lsb / 256.f;
  printf("temp: %f\n", temp);

  // std::cout<<(int)ret<<std::endl;
  return 0;
}
